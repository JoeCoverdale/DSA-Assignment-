<?php
require 'getPhoto.php';
require_once("../data/config.php");
require_once("../data/getPlacesOfInterest.php");

echo $poiVar[4];
getPhotos("powderham+castle");

?>