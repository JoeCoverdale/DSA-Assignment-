<?php
require 'getPhoto.php';
require_once("../data/config.php");
require_once("../data/getPlacesOfInterest.php");

echo $poiVar[6];
getPhotos("haldon&forest&exeter");

?>