<?php
    date_default_timezone_set('Europe/London');
    include_once 'dbComments.php';
?>


<!DOCTYPE html>
<?php

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" contents="IE=edge">
    <title>Sister Cities</title>     
    <meta name="assignment" contents="">   
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="newLayout.css">
</head>
<body>
   <header>
       <img class="uweLogo" src="img/logo.png" alt="uweLogo">
        <nav>
            <ul class="navBar">
                <li><a href="newLayout.php">User Comments</a></li>
                <li><a href="photo.php">Photo</a></li>
                <li><a href="weather.php">Weather</a></li>
                <li><a href="map.php">Map</a></li>
                <li><a href="rss.php">Rss Feed</a></li>
            </ul>
        </nav>
        <a class="signUp" href="#"><button>Sign Up/Login</button></a>
    </header>

    <u><h2 class="page-header">User Comments</h2></u>

    
  <div class = "commentForm">
  <?php
        echo "
        <form method='POST' action='".setComments($conn)."'>
        <label for='User_Name'>Name:</label> <br>
        <input id = 'rcornerName' type = 'text' name ='User_Name'><br>
        <input type = 'hidden' name ='DateTime' value='".date('Y-m-d H:i:s')."'>
        <label for='Comment'>Your Comment::</label> <br>
        <input ' type = 'hidden' name ='Comment'>
        <textarea id ='rcornerComment' name='Comment'></textarea><br>
        <button type = 'submit' name = 'commentSubmit'>Comment</button>
        </form>
        ";
    ?>
    </div>


  <div class = "comments">
  <?php
    postComments($conn);
  ?>
  </div>

  <div class = "bothFeeds">
    <div class = ExeterFeed>
      <iframe class = "leftFrame" src="../test/ExeterTwitterAPI.php?city=Exeter" width="100%" height="25%" frameborder="0" textalign="left"></iframe>
  </div>

    <div class = "RennesFeed">
      <iframe class = "righFrame" src="../test/RennesTwitterAPI.php?city=Rennes" width="100%" height="25%" frameborder="0"></iframe>
  </div>
</div>

</body>
</html>