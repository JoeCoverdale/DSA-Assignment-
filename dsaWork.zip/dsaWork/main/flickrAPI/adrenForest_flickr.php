<?php
require 'getPhoto.php';
require_once("../data/config.php");
require_once("../data/getPlacesOfInterest.php");

echo $poiVar[14];
getPhotos("zipline&forest&rennes");
?>